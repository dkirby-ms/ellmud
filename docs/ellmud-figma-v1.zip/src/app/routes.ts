import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import CharacterSelect from "./pages/CharacterSelect";
import Refuge from "./pages/Refuge";
import ShardExploration from "./pages/ShardExploration";
import Leaderboard from "./pages/Leaderboard";
import Settings from "./pages/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/characters",
    Component: CharacterSelect,
  },
  {
    path: "/refuge",
    Component: Refuge,
  },
  {
    path: "/shard/:shardId",
    Component: ShardExploration,
  },
  {
    path: "/leaderboard",
    Component: Leaderboard,
  },
  {
    path: "/settings",
    Component: Settings,
  },
]);
