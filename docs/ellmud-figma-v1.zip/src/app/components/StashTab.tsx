import { Package, Weight } from "lucide-react";

interface Item {
  id: string;
  name: string;
  type: string;
  tier: "common" | "sturdy" | "refined" | "masterwork" | "anomalous";
  durability: number;
  weight: number;
}

const mockItems: Item[] = [
  {
    id: "1",
    name: "Corroded Halberd",
    type: "Weapon",
    tier: "sturdy",
    durability: 65,
    weight: 8,
  },
  {
    id: "2",
    name: "Ironbound Chestplate",
    type: "Armor",
    tier: "refined",
    durability: 80,
    weight: 15,
  },
  {
    id: "3",
    name: "Veilkeeper's Tome",
    type: "Tool",
    tier: "masterwork",
    durability: 100,
    weight: 3,
  },
  {
    id: "4",
    name: "Shard-Touched Amulet",
    type: "Accessory",
    tier: "anomalous",
    durability: 95,
    weight: 1,
  },
  {
    id: "5",
    name: "Weathered Sword",
    type: "Weapon",
    tier: "common",
    durability: 40,
    weight: 5,
  },
];

const getTierColor = (tier: string) => {
  switch (tier) {
    case "common":
      return "#E8E0D0";
    case "sturdy":
      return "#6B8E6B";
    case "refined":
      return "#4682B4";
    case "masterwork":
      return "#7B4FA0";
    case "anomalous":
      return "#DAA520";
    default:
      return "#E8E0D0";
  }
};

export default function StashTab() {
  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h2
          className="text-[#C9A84C]"
          style={{ fontFamily: "var(--font-serif)", fontSize: "1.5rem" }}
        >
          Stash
        </h2>
        <div className="flex gap-4">
          <select
            className="bg-[#1C1D27] border border-[#2A2B35] rounded px-3 py-2 text-[#8A8B95] text-sm focus:border-[#C9A84C] focus:outline-none"
            style={{ fontFamily: "var(--font-sans)" }}
          >
            <option>All Types</option>
            <option>Weapons</option>
            <option>Armor</option>
            <option>Tools</option>
          </select>
          <select
            className="bg-[#1C1D27] border border-[#2A2B35] rounded px-3 py-2 text-[#8A8B95] text-sm focus:border-[#C9A84C] focus:outline-none"
            style={{ fontFamily: "var(--font-sans)" }}
          >
            <option>All Tiers</option>
            <option>Common</option>
            <option>Sturdy</option>
            <option>Refined</option>
            <option>Masterwork</option>
            <option>Anomalous</option>
          </select>
        </div>
      </div>

      <div className="grid gap-4">
        {mockItems.map((item) => (
          <div
            key={item.id}
            className="bg-[#12131A] border rounded-lg p-4 hover:border-[#C9A84C] transition-colors cursor-pointer"
            style={{
              borderColor: getTierColor(item.tier) + "40",
              borderLeftWidth: "4px",
            }}
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3
                  className="mb-1"
                  style={{
                    fontFamily: "var(--font-serif)",
                    fontSize: "1.125rem",
                    color: getTierColor(item.tier),
                  }}
                >
                  {item.name}
                </h3>
                <div className="flex items-center gap-3 mb-3">
                  <span
                    className="flex items-center gap-1 text-[#8A8B95] text-sm"
                    style={{ fontFamily: "var(--font-sans)" }}
                  >
                    <Package className="w-3 h-3" />
                    {item.type}
                  </span>
                  <span
                    className="flex items-center gap-1 text-[#8A8B95] text-sm"
                    style={{ fontFamily: "var(--font-sans)" }}
                  >
                    <Weight className="w-3 h-3" />
                    {item.weight} units
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-[#4A4B55] text-xs"
                    style={{ fontFamily: "var(--font-sans)" }}
                  >
                    Durability
                  </span>
                  <div className="flex-1 max-w-[200px] h-1.5 bg-[#1C1D27] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#2D6B4F] to-[#B8860B]"
                      style={{ width: `${item.durability}%` }}
                    ></div>
                  </div>
                  <span
                    className="text-[#8A8B95] text-xs"
                    style={{ fontFamily: "var(--font-mono)" }}
                  >
                    {item.durability}%
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  className="px-3 py-1 text-[#3A7D7B] hover:bg-[#1C1D27] rounded text-sm transition-colors"
                  style={{ fontFamily: "var(--font-sans)" }}
                >
                  Equip
                </button>
                <button
                  className="px-3 py-1 text-[#8A8B95] hover:bg-[#1C1D27] rounded text-sm transition-colors"
                  style={{ fontFamily: "var(--font-sans)" }}
                >
                  Inspect
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
