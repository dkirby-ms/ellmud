# Ellmud Content Admin Tool — Design Document

> **Purpose:** Specification for a designer-facing content management tool, separate from the existing debug/admin dashboard. This document is intended for UI/UX designers creating Figma mockups.
>
> **Status:** Draft
> **Author:** Elminster (Lead/Architect)
> **Date:** 2025-07-25

---

## Table of Contents

1. [Purpose & Audience](#1-purpose--audience)
2. [Content Domains](#2-content-domains)
3. [Information Architecture](#3-information-architecture)
4. [Screen-by-Screen Descriptions](#4-screen-by-screen-descriptions)
5. [Data Flow](#5-data-flow)
6. [Content Lifecycle](#6-content-lifecycle)
7. [Access Control](#7-access-control)
8. [Technical Integration Points](#8-technical-integration-points)
9. [Content Preview](#9-content-preview)
10. [Versioning & Rollback](#10-versioning--rollback)

---

## 1. Purpose & Audience

### 1.1 What This Tool Is

The **Content Admin Tool** is a web-based application for game designers to create, edit, preview, and publish all authored game content in Ellmud — without writing code or touching configuration files. It is the single source of truth for all game data that populates the procedural world: creatures, items, biomes, loot tables, shard modifiers, balance constants, narrative templates, and more.

This is **not** the existing admin dashboard described in GDD §13.3, which is a debug/inspection tool for live server state (Colyseus Schema sync, SSE telemetry, room/creature/player visibility). That dashboard observes the running game. This tool **authors the content the game runs on**.

### 1.2 Who Uses It

| Role | Description | Primary Tasks |
|------|-------------|---------------|
| **Designer** | Game designers, content authors, narrative writers | Create and edit content entries. Preview content in context. Submit content for review. |
| **Lead Designer** | Senior designers with approval authority | All designer tasks + review and approve/reject content changes. Manage content lifecycles. Set balance constants. |
| **Admin** | Technical leads with full system access | All lead designer tasks + manage user accounts and roles. Configure tool settings. Trigger content deployments. View audit logs. |

### 1.3 Problems It Solves

1. **Code-free content authoring.** Currently, all game content is defined in TypeScript files (`packages/server/src/creatures/templates/`, `packages/server/src/items/registry.ts`, `packages/server/src/shard/biomes/`). Adding a new creature, item, or biome requires a developer, a PR, and a deploy. The content admin tool decouples content authoring from the engineering pipeline.

2. **Validation at authoring time.** The tool enforces schema constraints, cross-reference integrity (e.g., a creature's loot table references only existing items), and balance ranges — surfacing errors before content reaches the game server.

3. **Content preview.** Designers can see how their creature, item, biome, or loot table will behave in context before publishing, reducing iteration cycles.

4. **Auditable content lifecycle.** Every content change has an author, a timestamp, a review trail, and version history. Changes can be rolled back without code deploys.

5. **Parallel workflows.** Multiple designers can work on different content domains simultaneously (one on creatures, another on a new biome) without merge conflicts in source files.

### 1.4 Relationship to Existing Systems

```
┌───────────────────────┐     Publishes content     ┌─────────────────────────┐
│  Content Admin Tool   │ ──────────────────────────►│  PostgreSQL             │
│  (this document)      │     (content tables)       │  (content_* tables)     │
│                       │                            │                         │
│  • Authors content    │     On server startup /    │  ┌─────────────────┐    │
│  • Preview & validate │     hot-reload signal      │  │ Game Server     │    │
│  • Version & rollback │◄──────────────────────────│  │ (Colyseus)      │    │
│                       │     Reads published        │  │                 │    │
└───────────────────────┘     content                │  │ Loads content   │    │
                                                     │  │ from DB at      │    │
┌───────────────────────┐                            │  │ shard seeding   │    │
│  Admin Dashboard      │     Observes live state    │  └─────────────────┘    │
│  (existing, GDD §13.3)│ ◄──SSE telemetry──────────│                         │
│  • Debug/inspect      │                            └─────────────────────────┘
│  • Live state viewer  │
└───────────────────────┘
```

---

## 2. Content Domains

Each content domain maps to one or more GDD sections and one or more existing data models in the codebase. The admin tool provides a dedicated management interface for each.

### 2.1 Creatures (GDD §6.6, §10.4)

**What designers manage:** Creature archetypes (templates) that define stats, behaviour, loot, and spawn rules.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `type` | Unique slug | `^[a-z_]+$`, max 50 chars | `CreatureType` |
| `name` | Display name | Required, max 100 chars | `CreatureTemplate.name` |
| `stats.maxHp` | Integer | 1–10,000 | `CombatStats.maxHp` |
| `stats.attack` | Integer | 0–500 | `CombatStats.attack` |
| `stats.defence` | Integer | 0–500 | `CombatStats.defence` |
| `stats.armour` | Integer | 0–500 | `CombatStats.armour` |
| `lootTable` | Array of loot entries | 1–20 entries; each references an existing item | `LootEntry[]` |
| `spawnRules.minCount` | Integer | 0–50 | `SpawnRules.minCount` |
| `spawnRules.maxCount` | Integer | ≥ minCount, ≤ 50 | `SpawnRules.maxCount` |
| `spawnRules.preferredRoomTypes` | Multi-select | From `RoomType` enum | `SpawnRules.preferredRoomTypes` |
| `spawnRules.forbiddenRoomTypes` | Multi-select | From `RoomType` enum | `SpawnRules.forbiddenRoomTypes` |
| `idleTicksMin` | Integer | 1–60 | `CreatureTemplate.idleTicksMin` |
| `idleTicksMax` | Integer | ≥ idleTicksMin, ≤ 60 | `CreatureTemplate.idleTicksMax` |
| `fleeThreshold` | Decimal | 0.0–1.0 | `CreatureTemplate.fleeThreshold` |
| `biomeAffinity` | Multi-select | From `BiomeType` enum | New field — which biomes this creature can appear in |
| `tierRange` | Shard tier range | 1–3, min ≤ max | New field — which shard tiers this creature spawns in |
| `behaviorArchetype` | Select | berserker / skulker / guardian / patrol (GDD §6.6) | New field — AI personality |
| `description` | Rich text | For narrative context; provided to LLM | New field |

**Cross-references:** Loot table entries → Items. Biome affinity → Biomes. Spawn room types → Room Types.

### 2.2 Items (GDD §7.2, §9.1)

**What designers manage:** Item definitions — weapons, armour, consumables, materials, tools, keys, and blueprints.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `id` | Unique slug | `^[a-z_]+$`, max 50 chars | `ItemDefinition.id` |
| `name` | Display name | Required, max 100 chars | `ItemDefinition.name` |
| `type` | Select | weapon / armour / consumable / material / tool / key / blueprint | `ItemType` |
| `tier` | Select | scrap / common / sturdy / refined / masterwork / anomalous | `GearTier` |
| `baseStats` | Conditional fields | Depends on `type` — see below | `ItemStats` |
| `baseDurability` | Integer or null | 0–1,000; null for non-degradable items | `ItemDefinition.baseDurability` |
| `weight` | Decimal | 0.1–100.0 | `ItemDefinition.weight` |
| `description` | Text | Required, max 500 chars | `ItemDefinition.description` |
| `soulbound` | Boolean | Default false | `ItemDefinition.soulbound` |

**Conditional stat fields by item type:**

| Item Type | Stats Fields | Source |
|-----------|-------------|--------|
| Weapon | `damage` (1–500), `speed` (1–10 ticks) | `WeaponStats` |
| Armour | `armour` (1–200), `weight` (0.1–100) | `ArmourStats` |
| Consumable | `heal?` (0–500), `staminaRestore?` (0–200), `duration?` (1–60 ticks) | `ConsumableStats` |
| Material | — (no combat stats) | — |
| Tool | — (tool-specific, extensible) | — |
| Key | — (no stats) | — |
| Blueprint | `unlocksRecipeId` (reference) | New field |

**Cross-references:** Blueprint → Recipe. Items appear in creature loot tables, biome loot tables, and room containers.

### 2.3 Biomes (GDD §10.2)

**What designers manage:** Biome definitions that control room templates, creature pools, loot tables, hazards, and atmosphere for procedurally generated shards.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `type` | Unique slug | `^[a-z_]+$`, max 50 chars | `BiomeType` |
| `name` | Display name | Required, max 100 chars | — |
| `flavour` | Text | Short thematic description, max 200 chars | GDD §10.2 |
| `roomNames` | Object map | Names per `RoomType` — each a list of 5–20 names | `ROOM_NAMES` in biome files |
| `roomDescriptions` | Object map | Description templates per `RoomType` | `ROOM_DESCRIPTIONS` in biome files |
| `lootTable` | Array of loot entries | Each: `itemId` (ref), `weight` (1–100), `containerType` (crate/chest/altar/corpse) | `LOOT_TABLE` |
| `hazardTemplates` | Array of hazards | Each: `type` (slug), `baseSeverity` (0.0–1.0) | `HAZARD_TEMPLATES` |
| `signatureCreature` | Reference | Links to a creature template | GDD §10.2 |
| `signatureHazard` | Text | Human-readable signature hazard | GDD §10.2 |
| `ambientSounds` | Text list | Atmospheric audio cues for LLM narration | New field |
| `lightLevelRange` | Min/max decimal | 0.0–1.0 | GDD §4.3 (`light_level`) |

**Cross-references:** Loot table → Items. Signature creature → Creatures. Room names/descriptions define the LLM narration context.

### 2.4 Shard Modifiers (GDD §10.3)

**What designers manage:** Named modifiers that alter shard run parameters. Each shard rolls 1–3 modifiers at seeding time.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `id` | Unique slug | `^[a-z_]+$`, max 50 chars | `ShardModifier` |
| `name` | Display name | Required, max 100 chars | — |
| `description` | Text | Player-facing description, max 300 chars | GDD §10.3 |
| `effects` | Structured effects | Key-value pairs defining mechanical changes | — |
| `stackable` | Boolean | Whether this modifier can co-occur with itself | — |
| `exclusions` | Multi-select | Modifiers that cannot co-occur | — |
| `tierAvailability` | Multi-select | Which shard tiers (1, 2, 3) can roll this modifier | — |
| `weight` | Integer | Roll weight (higher = more common), 1–100 | — |

**Effect types** (each is optional; a modifier may set one or more):

| Effect Key | Type | Example | GDD Reference |
|------------|------|---------|---------------|
| `roomCountMultiplier` | Decimal | 1.3 (Dense = +30%) | Dense modifier |
| `lootTierBonus` | Integer | 1 (Bountiful = +1 tier) | Bountiful modifier |
| `soundPropagationMultiplier` | Decimal | 0.5 (Silent = halved) | Silent modifier |
| `globalLightLevel` | Decimal | 0.1 (Dark) | Dark modifier |
| `passiveDamagePerTick` | Integer | 1 (Cursed) | Cursed modifier |
| `healingEffectivenessMultiplier` | Decimal | 0.5 (Cursed) | Cursed modifier |
| `spawnEliteCreature` | Boolean | true (Hunted) | Hunted modifier |
| `connectionDecayEnabled` | Boolean | true (Fractured) | Fractured modifier |
| `symmetricLayout` | Boolean | true (Mirrored) | Mirrored modifier |

### 2.5 Loot Tables (GDD §10.4)

**What designers manage:** Reusable loot table definitions used by creatures, biomes, and room containers.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `id` | Unique slug | `^[a-z_]+$`, max 50 chars | — |
| `name` | Display name | Required, max 100 chars | — |
| `entries` | Array of drops | 1–50 entries | `DropTable.entries` |
| `entries[].itemId` | Reference | Must reference existing item | `DropTableEntry.itemId` |
| `entries[].weight` | Integer | 1–1,000 (relative probability) | `DropTableEntry.weight` |
| `dropCount` | Integer or range | `min` and `max` drop count per roll | `DropTable.dropCount` |
| `tierRestriction` | Select | Max `GearTier` allowed in this table (filters items) | `SHARD_TIER_MAX_RARITY` |
| `context` | Tag | creature / biome / container / event | New field — where this table is used |

**Cross-references:** Every entry → Item. Tables are referenced by Creatures (loot on death) and Biomes (room container loot).

### 2.6 Skills (GDD §7.1)

**What designers manage:** Skill definitions, categories, levelling curves, and soft caps.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `name` | Unique slug | `^[a-z_]+$`, max 50 chars | `PlayerSkill.skill_name` |
| `displayName` | Display name | Required, max 100 chars | — |
| `category` | Select | combat / defence / survival / subterfuge / awareness / social | `SkillCategory` |
| `description` | Text | What this skill does, max 300 chars | GDD §7.1 |
| `maxLevel` | Integer | 1–100 | — |
| `xpCurve` | Curve type + params | linear / exponential / logarithmic + base + scaling factor | — |
| `softCapLevel` | Integer | Level at which diminishing returns begin | GDD §7.1 |
| `softCapMultiplier` | Decimal | XP multiplier after soft cap (e.g., 0.5 = half XP rate) | — |
| `passiveEffects` | Array | Structured effects per level milestone | — |

**Cross-references:** Category groups skills. Passive effects may reference combat stats, detection ranges, etc.

### 2.7 Factions (GDD §9.4)

**What designers manage:** Faction definitions, rank structures, reputation thresholds, and unlocks.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `slug` | Unique slug | `^[a-z_]+$`, max 50 chars | `FactionSlugs` |
| `name` | Display name | Required, max 100 chars | `Faction.name` |
| `philosophy` | Text | Faction identity, max 300 chars | `Faction.philosophy` |
| `specialty` | Text | Gameplay specialty, max 300 chars | `Faction.specialty` |
| `ranks` | Array of rank defs | Ordered list; each has `name`, `reputationRequired`, `unlocks` | — |
| `ranks[].unlocks` | Array | Recipe IDs, passive perk IDs, gear IDs unlocked at this rank | — |

**Cross-references:** Rank unlocks → Items, Recipes. Faction membership is one-per-player (GDD §9.4).

### 2.8 Room Templates (GDD §10.1, §10.2)

**What designers manage:** Named room templates that the procedural generator selects from when building shard graphs.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `id` | Unique slug | `^[a-z_]+$`, max 50 chars | — |
| `name` | Display name | Required, max 100 chars | Biome `ROOM_NAMES` |
| `roomType` | Select | entry / extraction / boss / corridor / junction / dead_end | `RoomType` |
| `biome` | Reference | Which biome this template belongs to | `BiomeType` |
| `descriptionTemplate` | Rich text | Handlebars-style template for LLM context | Biome `ROOM_DESCRIPTIONS` |
| `features` | Tag list | Environmental features (e.g., collapsed_pillar, altar_bloodstained) | GDD §4.3 |
| `defaultLightLevel` | Decimal | 0.0–1.0 | GDD §4.3 |
| `soundPropagationModifier` | Decimal | 0.5–2.0 (multiplier on noise passing through) | GDD §12.2 |
| `hazardSlots` | Integer | 0–5, how many hazards this room can have | — |

**Cross-references:** Biome → Room Templates (1:many). Features are used by the LLM narration context.

### 2.9 Narrative Templates (GDD §4.2, §4.4, §4.5)

**What designers manage:** Handlebars-style fallback templates used when the LLM times out or cache misses. Also, tone presets and narrative directive configurations.

| Field | Type | Constraints | Source |
|-------|------|-------------|--------|
| `id` | Unique slug | `^[a-z_]+$`, max 50 chars | — |
| `narrationTypeScope` | Select | room_description / combat_action / combat_round / movement / event | `LLMNarrationType` |
| `biomeScope` | Reference or "all" | Which biome this template applies to | — |
| `template` | Handlebars text | Uses `{{room.biome}}`, `{{creature.name}}`, etc. | Template fallback system |
| `tone` | Select | dread / wonder / tension / calm | `NarrativeDirectives.tone` |
| `verbosity` | Select | terse / standard / verbose | `NarrativeDirectives.verbosity` |
| `maxTokens` | Integer | 20–500 | `NarrationModelConfig.max_tokens` |

**Cross-references:** Biome scope → Biomes. Narration type → LLM pipeline configuration.

### 2.10 Balance Constants (GDD §5.2, §6.4, §7.1, §10, §12)

**What designers manage:** Game-wide numerical constants that govern balance. These are the tuning knobs that don't belong to any single entity.

| Constant Group | Examples | Source |
|---------------|----------|--------|
| **Combat** | `DEFAULT_PLAYER_STATS` (maxHp: 100, attack: 10, defence: 5, armour: 2), `COMBAT_TIMEOUT_TICKS` (10), stance multiplier matrix | `CombatState.ts`, `damage.ts` |
| **Shard Generation** | `TIER_ROOM_COUNTS`, `TIER_ANCHORS`, `MIN_ENTRY_TO_EXTRACTION_HOPS` (5) | `generator.ts` |
| **Loot Economy** | `RARITY_TIERS` (stat/durability/drop multipliers), `SHARD_TIER_MAX_RARITY`, `CREATURE_DROP_COUNTS` | `items.ts`, `loot-drops.ts` |
| **Inventory** | `DEFAULT_STASH_CAPACITY` (200), `MAX_LOADOUT_WEIGHT` (100), `MAX_CONSUMABLE_SLOTS` (5), `DEFAULT_MAX_CARRY_WEIGHT` (20) | Various |
| **Extraction** | `EXTRACTION_NOISE_LEVEL` (8), extraction tick duration (5 ticks) | `ExtractionSystem.ts` |
| **Sound** | Noise values per action (walk: 2, run: 4, combat: 5, door: 7, explosion: 9, extraction: 8), attenuation per room (2) | GDD §12.2 |
| **Narration** | Timeout budgets (combat: 800ms, room: 2000ms, hard: 3000ms), cache TTLs, temperature, max tokens per type | `narrative-types.ts` |

### 2.11 Contracts (GDD §2.1, §9.4) — *Phase 4*

**What designers manage:** Daily/weekly objectives that grant faction reputation and materials.

| Field | Type | Constraints |
|-------|------|-------------|
| `id` | Unique slug | `^[a-z_]+$` |
| `name` | Display name | Required |
| `faction` | Reference | Which faction offers this contract |
| `type` | Select | daily / weekly |
| `objectives` | Array | Structured objectives (kill X creatures, extract Y items, etc.) |
| `rewards` | Array | Item refs + reputation amount |
| `tierRequirement` | Shard tier | Minimum shard tier to accept |

### 2.12 Crafting Recipes (GDD §9.2) — *Phase 3*

**What designers manage:** Recipes gated by faction rank and skill level.

| Field | Type | Constraints |
|-------|------|-------------|
| `id` | Unique slug | `^[a-z_]+$` |
| `name` | Display name | Required |
| `outputItem` | Reference | Item produced |
| `materials` | Array | Item refs + quantities required |
| `requiredFaction` | Reference | Faction + minimum rank |
| `requiredSkill` | Reference | Skill name + minimum level |
| `qualityVariance` | Decimal | 0.0–1.0, how much output quality varies |

---

## 3. Information Architecture

### 3.1 Global Navigation

The tool uses a **persistent left sidebar** navigation with top-level sections. The main content area occupies the right ~80% of the viewport. A **top bar** shows the current user, role badge, environment indicator (staging/production), and a global search field.

```
┌──────────────────────────────────────────────────────────────────────┐
│  ⚙ Ellmud Content Admin          [Search content...]    🔔  👤 Jane │
├──────────┬───────────────────────────────────────────────────────────┤
│          │                                                           │
│ 📊 Dash  │                    Main Content Area                      │
│          │                                                           │
│ ⚔ Creat. │            (List view, detail view, or editor             │
│ 🗡 Items  │             depending on selected section)                │
│ 🏔 Biomes │                                                           │
│ 🎲 Mods   │                                                           │
│ 💎 Loot   │                                                           │
│ 📈 Skills │                                                           │
│ 🏛 Factions│                                                          │
│ 🏠 Rooms  │                                                           │
│ 📝 Narr.  │                                                           │
│ ⚖ Balance│                                                           │
│ 📋 Contr. │                                                           │
│ 🔨 Recipes│                                                           │
│          │                                                           │
│ ──────── │                                                           │
│ 📦 Deploy │                                                           │
│ 📜 Audit  │                                                           │
│ 👥 Users  │                                                           │
└──────────┴───────────────────────────────────────────────────────────┘
```

**Sidebar sections:**

| Section | Label | Content Domain |
|---------|-------|----------------|
| Dashboard | Dashboard | Overview metrics, recent changes, pending reviews |
| Creatures | Creatures | Creature templates (§2.1) |
| Items | Items | Item definitions (§2.2) |
| Biomes | Biomes | Biome definitions (§2.3) |
| Modifiers | Shard Modifiers | Shard modifier definitions (§2.4) |
| Loot Tables | Loot Tables | Loot table definitions (§2.5) |
| Skills | Skills | Skill definitions (§2.6) |
| Factions | Factions | Faction definitions (§2.7) |
| Room Templates | Rooms | Room template definitions (§2.8) |
| Narrative | Narrative | Narrative templates & directives (§2.9) |
| Balance | Balance | Game-wide constants (§2.10) |
| Contracts | Contracts | Contract definitions (§2.11) |
| Recipes | Recipes | Crafting recipes (§2.12) |
| — separator — | | |
| Deploy | Deploy | Content deployment pipeline |
| Audit Log | Audit Log | Change history across all domains |
| Users | Users | User management (Admin only) |

### 3.2 Common Page Patterns

Every content domain follows one of two page patterns:

#### Pattern A: List → Detail (used by Creatures, Items, Biomes, Modifiers, Skills, Factions, Rooms, Narrative, Contracts, Recipes)

1. **List view** — Filterable, sortable table of all entries in the domain. Columns vary by domain. Actions: Create New, bulk select, filter by status/tier/biome.
2. **Detail/Edit view** — Full form for a single entry. Accessed by clicking a row in the list. Contains all fields, validation, cross-reference pickers, and a side panel showing version history and related entities.

#### Pattern B: Grouped Editor (used by Loot Tables, Balance Constants)

1. **Grouped view** — Content organized into collapsible groups (e.g., balance constants grouped by Combat / Shard Gen / Loot Economy / Inventory / Extraction / Sound / Narration). Each group expands to show editable fields inline.

### 3.3 Common UI Components

These components appear across multiple screens:

| Component | Description | Used In |
|-----------|-------------|---------|
| **Status Badge** | Coloured pill showing content lifecycle state: Draft (grey), In Review (amber), Published (green), Deprecated (red) | All list views, detail headers |
| **Reference Picker** | Searchable dropdown that links to another content entry (e.g., select an item for a loot table). Shows the referenced entity's name, type, and tier. | Creature loot, biome loot, recipes, contracts |
| **Version History Panel** | Right-side collapsible panel showing all past versions of the current entry, with diff viewer | All detail views |
| **Validation Summary** | Inline error/warning indicators on fields, plus a top-level summary bar | All edit forms |
| **Preview Panel** | Contextual preview of how content will appear in-game (narrated text, stat blocks, loot roll simulations) | Creatures, Items, Biomes, Narrative |
| **Bulk Action Bar** | Appears when multiple list items are selected. Actions: Publish, Deprecate, Export, Delete Draft | All list views |
| **Content Diff Viewer** | Side-by-side comparison of two versions (or current vs published) | Version history, review workflow |
| **Cross-Reference Card** | Small card showing entities that reference the current entry (e.g., "Used by 3 creatures, 2 biome loot tables") | All detail views |

### 3.4 Workflows

#### Create New Content
1. Click "Create New" on any list view
2. Fill in required fields (form validates as you type)
3. Save as Draft (persisted, not visible to game server)
4. Optionally preview in context
5. Submit for Review (changes status to "In Review")

#### Review & Publish
1. Lead Designer sees pending reviews on Dashboard or filters any list by "In Review"
2. Opens the detail view; sees a diff against the currently published version (if any)
3. Approves → status changes to "Published"; content becomes available to game server
4. Or Rejects → status reverts to "Draft" with review comments

#### Edit Published Content
1. Editing a published entry creates a new **draft version** — the published version remains live
2. The draft goes through the same review cycle
3. On approval, the new version replaces the published one atomically
4. The previous version is retained in version history for rollback

#### Deprecate Content
1. Lead Designer marks content as "Deprecated"
2. Deprecated content is excluded from new shard generation but remains in active shards until they collapse
3. Can be un-deprecated (reverts to Published)

---

## 4. Screen-by-Screen Descriptions

### 4.1 Dashboard

**Purpose:** Landing page. At-a-glance overview of content health, recent activity, and pending actions.

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  Dashboard                                                           │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐   │
│  │ 47 Total    │ │ 3 In Review │ │ 38 Published│ │ 2 Deprecated│   │
│  │ Creatures   │ │ ⏳ Pending  │ │ ✅ Live     │ │ ⚠ Sunset   │   │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘   │
│                                                                      │
│  ┌────────────────────────────────────┐ ┌─────────────────────────┐ │
│  │  Recent Changes                    │ │  Pending Reviews        │ │
│  │                                    │ │                         │ │
│  │  • Jane edited Drowned Revenant    │ │  • Cinder Wraith (new)  │ │
│  │    2 min ago                       │ │    by Jane — 3h ago     │ │
│  │  • Bob published Fungal Deep biome │ │  • Ember Rift biome     │ │
│  │    1h ago                          │ │    by Bob — 1d ago      │ │
│  │  • Jane added Iron Greatsword      │ │                         │ │
│  │    3h ago                          │ │  [Review All →]         │ │
│  │                                    │ │                         │ │
│  │  [View All Activity →]            │ │                         │ │
│  └────────────────────────────────────┘ └─────────────────────────┘ │
│                                                                      │
│  ┌────────────────────────────────────┐ ┌─────────────────────────┐ │
│  │  Content Coverage                  │ │  Validation Warnings    │ │
│  │                                    │ │                         │ │
│  │  Creatures: ████████░░ 8/10 biomes │ │  ⚠ 2 creatures have    │ │
│  │  Items:     ██████████ 18 defined  │ │    empty loot tables    │ │
│  │  Biomes:    ██░░░░░░░░ 1/5 done   │ │  ⚠ Shattered Bastion   │ │
│  │  Modifiers: █████████░ 5/8 done   │ │    missing room names   │ │
│  │  Skills:    ░░░░░░░░░░ 0 defined  │ │                         │ │
│  └────────────────────────────────────┘ └─────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────┘
```

**Key elements:**
- **Stat cards (top row):** Total content count across all domains, items pending review, published count, deprecated count. Each card is clickable, filtering to that state.
- **Recent Changes (left middle):** Chronological feed of content edits across all domains. Shows author avatar, action (created/edited/published/deprecated), entity name, and timestamp. Links to the changed entity.
- **Pending Reviews (right middle):** List of content entries awaiting Lead Designer approval. Shows entity name, author, time since submission. "Review All" link navigates to a filtered cross-domain review queue.
- **Content Coverage (left bottom):** Progress bars per domain showing how much content exists vs. what the GDD specifies (e.g., 5 biomes needed, 1 defined). Helps designers see what's missing.
- **Validation Warnings (right bottom):** Cross-domain validation issues. Broken references, empty required fields on published content, balance anomalies (e.g., a creature with 0 attack).

**Actions:** No CRUD here — dashboard is read-only with navigation links to relevant detail screens.

### 4.2 Creatures — List View

**Purpose:** Browse, filter, and manage all creature templates.

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  Creatures                                    [+ Create Creature]    │
├──────────────────────────────────────────────────────────────────────┤
│  Filters: [Status ▾] [Biome ▾] [Tier Range ▾]  🔍 Search...        │
├──────────────────────────────────────────────────────────────────────┤
│  ☐ │ Name               │ Type             │ HP   │ Biome(s)│Status│
│  ──┼────────────────────┼──────────────────┼──────┼─────────┼──────│
│  ☐ │ Drowned Revenant   │ drowned_revenant │ 50   │ FC      │ ✅   │
│  ☐ │ Ironbound Sentinel │ ironbound_sent.  │ 80   │ SB      │ ✅   │
│  ☐ │ Sporeweaver        │ sporeweaver      │ 40   │ FD      │ ⏳   │
│  ☐ │ Cinder Wraith      │ cinder_wraith    │ 60   │ ER      │ 📝   │
│  ☐ │ Ink Horror         │ ink_horror       │ 70   │ HA      │ 📝   │
├──────────────────────────────────────────────────────────────────────┤
│  Showing 5 of 5 │ ◀ 1 ▶                                             │
└──────────────────────────────────────────────────────────────────────┘
```

**Columns:**
- Checkbox (for bulk actions)
- **Name** — display name, clickable to open detail view
- **Type** — slug identifier
- **HP** — maxHp stat (quick reference)
- **Biome(s)** — abbreviated biome affinity tags (FC = Flooded Crypt, SB = Shattered Bastion, etc.)
- **Status** — badge: 📝 Draft, ⏳ In Review, ✅ Published, ⛔ Deprecated

**Filters:** Status (multi-select), Biome affinity (multi-select), Tier range (1/2/3).

**Actions:**
- **Create Creature** button (top right) — opens new creature form
- **Row click** — opens creature detail/edit view
- **Bulk action bar** (appears when checkboxes selected): Publish, Deprecate, Delete Draft

### 4.3 Creatures — Detail / Edit View

**Purpose:** Full creature template editor with validation, preview, and version history.

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  ← Creatures  /  Drowned Revenant                  ✅ Published v3   │
│                                          [Save Draft] [Submit Review]│
├─────────────────────────────────────┬────────────────────────────────┤
│                                     │                                │
│  Identity                           │  Preview                       │
│  ┌────────────────────────────────┐ │  ┌──────────────────────────┐ │
│  │ Type: [drowned_revenant     ] │ │  │ === Stat Block ===       │ │
│  │ Name: [Drowned Revenant     ] │ │  │ HP: 50 | ATK: 10        │ │
│  │ Description:                  │ │  │ DEF: 3  | ARM: 3        │ │
│  │ [A waterlogged corpse risen  │ │  │                          │ │
│  │  from the crypts below...]   │ │  │ Flee at: 25% HP          │ │
│  │ Behavior: [Guardian ▾]       │ │  │ Tier: 1                  │ │
│  └────────────────────────────────┘ │  │ Biomes: Flooded Crypt   │ │
│                                     │  └──────────────────────────┘ │
│  Combat Stats                       │                                │
│  ┌────────────────────────────────┐ │  Loot Simulation              │
│  │ Max HP:  [50  ] Attack: [10 ] │ │  ┌──────────────────────────┐ │
│  │ Defence: [3   ] Armour: [3  ] │ │  │ 100-roll simulation:     │ │
│  └────────────────────────────────┘ │  │ waterlogged bone: 58%    │ │
│                                     │  │ revenant essence: 42%    │ │
│  Spawn Rules                        │  │ [Re-roll Simulation]     │ │
│  ┌────────────────────────────────┐ │  └──────────────────────────┘ │
│  │ Min Count: [3]  Max Count: [5]│ │                                │
│  │ Preferred rooms: [corridor ✕] │ │  Version History               │
│  │                   [dead_end ✕]│ │  ┌──────────────────────────┐ │
│  │ Forbidden rooms: [entry ✕]    │ │  │ v3 (current) - Published │ │
│  │                   [extraction✕]│ │  │   Jane, 2h ago           │ │
│  │ Idle ticks: [3] to [5]       │ │  │ v2 - Jane, 1d ago        │ │
│  │ Flee threshold: [0.25]        │ │  │ v1 - Bob, 3d ago         │ │
│  └────────────────────────────────┘ │  │ [Compare Versions]       │ │
│                                     │  └──────────────────────────┘ │
│  Biome & Tier                       │                                │
│  ┌────────────────────────────────┐ │  Referenced By                 │
│  │ Biome affinity: [flooded_crypt│ │  ┌──────────────────────────┐ │
│  │                  ✕]           │ │  │ Biome: Flooded Crypt     │ │
│  │ Tier range: [1] to [3]       │ │  │   (signature creature)   │ │
│  └────────────────────────────────┘ │  └──────────────────────────┘ │
│                                     │                                │
│  Loot Table                         │                                │
│  ┌────────────────────────────────┐ │                                │
│  │ Item              │ Weight     │ │                                │
│  │ waterlogged bone  │ [60]       │ │                                │
│  │ revenant essence  │ [40]       │ │                                │
│  │ [+ Add Loot Entry]            │ │                                │
│  └────────────────────────────────┘ │                                │
├─────────────────────────────────────┴────────────────────────────────┤
│  Validation: ✅ All fields valid                                     │
└──────────────────────────────────────────────────────────────────────┘
```

**Left column (editor form):**
- **Identity section:** Type slug (read-only after creation), display name, rich-text description, behavior archetype dropdown (berserker/skulker/guardian/patrol).
- **Combat Stats section:** Numeric inputs for maxHp, attack, defence, armour. Inline range indicators (shows "typical Tier 1 range: 30–80 HP").
- **Spawn Rules section:** Min/max count, multi-select tag pickers for preferred and forbidden room types, idle tick range, flee threshold slider (0.0–1.0).
- **Biome & Tier section:** Multi-select biome affinity tags, tier range slider (1–3).
- **Loot Table section:** Editable table of loot entries. Each row has a Reference Picker for item and a weight input. "Add Loot Entry" button appends a row. Drag handles for reordering. Delete (×) button per row.

**Right column (context panels):**
- **Preview panel:** Stat block summary. Live-updating as form fields change.
- **Loot Simulation panel:** Runs a configurable number of simulated loot rolls (default 100) and shows drop probability per item. "Re-roll" button re-runs.
- **Version History panel:** Collapsible list of all versions. Click any version to load a read-only diff view. "Compare Versions" opens side-by-side diff.
- **Referenced By panel:** Shows all other content entries that reference this creature (biome signature creature, contracts that require killing it, etc.).

**Validation rules:**
- `type` must be unique across all creatures (case-insensitive)
- `name` required, max 100 chars
- `maxHp` ≥ 1
- `attack`, `defence`, `armour` ≥ 0
- `spawnRules.maxCount` ≥ `spawnRules.minCount`
- `idleTicksMax` ≥ `idleTicksMin`
- `fleeThreshold` between 0.0 and 1.0
- Loot table: at least 1 entry; all `itemId` references must resolve to existing published or draft items
- At least one biome affinity selected
- Tier range: min ≤ max

**Actions:**
- **Save Draft** — persists current state without changing lifecycle status
- **Submit for Review** — sets status to "In Review" (only available when status is Draft)
- **Publish** (Lead Designer only) — sets status to Published
- **Reject** (Lead Designer only) — reverts to Draft with comment
- **Deprecate** (Lead Designer only) — marks as Deprecated

### 4.4 Items — List View

**Purpose:** Browse all item definitions with filtering by type, tier, and status.

**Layout:** Same Pattern A list structure as Creatures.

**Columns:**
- Checkbox
- **Name** — display name
- **Type** — weapon / armour / consumable / material / tool / key / blueprint
- **Tier** — colour-coded gear tier badge (scrap=grey, common=white, sturdy=green, refined=blue, masterwork=purple, anomalous=gold)
- **Weight** — numeric
- **Soulbound** — ✓ or —
- **Status** — lifecycle badge

**Filters:** Status, Type (multi-select), Tier (multi-select), Soulbound (yes/no).

**Sort:** Name (A-Z / Z-A), Tier (ascending / descending), Weight, Recently modified.

### 4.5 Items — Detail / Edit View

**Purpose:** Full item definition editor with type-conditional stat fields.

**Layout:** Two-column layout matching the creature detail pattern.

**Left column (editor form):**
- **Identity section:** ID slug, display name, description (text area).
- **Classification section:** Type dropdown (weapon/armour/consumable/material/tool/key/blueprint), Tier dropdown, Soulbound toggle.
- **Stats section:** **Dynamically rendered based on type selection:**
  - Weapon selected → shows `damage` and `speed` fields
  - Armour selected → shows `armour` and `weight` fields
  - Consumable selected → shows `heal`, `staminaRestore`, `duration` fields (all optional)
  - Material/Tool/Key → no stat fields shown
  - Blueprint → shows `unlocksRecipeId` Reference Picker
- **Physical section:** Weight (decimal input), Base Durability (integer input or "Non-degradable" toggle).

**Right column (context panels):**
- **Preview panel:** Rendered item card showing name, tier colour, stats, weight, durability bar.
- **Effective Stats panel:** Shows actual in-game stats after applying `RARITY_TIERS` multipliers. E.g., if base damage is 10 and tier is "sturdy" (1.2x multiplier), shows "Effective damage: 12".
- **Used In panel:** Lists all creatures, loot tables, biomes, and recipes that reference this item.
- **Version History panel.**

**Validation rules:**
- `id` unique across all items
- `name` required, max 100 chars
- `type` required
- `tier` required
- Weapon: `damage` ≥ 1, `speed` ≥ 1
- Armour: `armour` ≥ 1
- Consumable: at least one of `heal`, `staminaRestore`, `duration` must be set
- `weight` ≥ 0.1
- `baseDurability` ≥ 1 if not null
- Blueprint: `unlocksRecipeId` must reference an existing recipe

### 4.6 Biomes — List View

**Columns:**
- **Name** — display name
- **Type** — slug
- **Signature Creature** — linked creature name (clickable)
- **Signature Hazard** — text
- **Room Templates** — count of associated room templates
- **Loot Entries** — count
- **Status** — lifecycle badge

**Filters:** Status.

### 4.7 Biomes — Detail / Edit View

**Purpose:** Comprehensive biome editor. Biomes are the most complex content type — they contain room names, descriptions, loot tables, hazards, and cross-references to creatures.

**Layout:** Tabbed interface within the detail view. Tabs: **Overview**, **Room Names**, **Room Descriptions**, **Loot Table**, **Hazards**.

**Tab: Overview**
- Type slug (read-only after creation)
- Display name
- Flavour text (short atmospheric description)
- Signature creature (Reference Picker → Creatures)
- Signature hazard (text)
- Ambient sounds (tag list input — freeform text tags)
- Light level range (dual slider, 0.0–1.0)

**Tab: Room Names**
- Grouped by `RoomType` (entry, extraction, boss, corridor, junction, dead_end)
- Each group is a text list editor (add/remove/reorder names)
- Minimum 5 names per room type recommended (validation warning if fewer)
- Maximum 20 names per room type

```
┌─────────────────────────────────────────────┐
│  Room Names                                  │
│                                              │
│  ▼ Entry (6 names)                           │
│    • Drowned Vestibule                    [×]│
│    • Sunken Threshold                     [×]│
│    • Waterlogged Gate                     [×]│
│    • Flooded Anteroom                     [×]│
│    • Tidal Entrance                       [×]│
│    • Submerged Arch                       [×]│
│    [+ Add name]                              │
│                                              │
│  ▶ Extraction (4 names)                      │
│  ▶ Boss (3 names)                            │
│  ▶ Corridor (8 names)                        │
│  ▶ Junction (5 names)                        │
│  ▶ Dead End (6 names)                        │
└─────────────────────────────────────────────┘
```

**Tab: Room Descriptions**
- Same grouping by `RoomType`
- Each entry is a rich text / Handlebars template editor
- Supports template variables: `{{room.name}}`, `{{room.light_level}}`, `{{room.hazards}}`, `{{room.creatures}}`
- Preview button renders a sample description using mock data

**Tab: Loot Table**
- Editable table of loot entries (same pattern as creature loot table)
- Each row: Item (Reference Picker), Weight (integer), Container Type (dropdown: crate/chest/altar/corpse)
- Running probability calculation shown per row
- Total weight shown at bottom

**Tab: Hazards**
- Editable list of hazard templates
- Each row: Type slug (text), Base Severity (decimal slider 0.0–1.0), Description (text)
- Add/remove/reorder

**Right column (always visible across tabs):**
- Content coverage indicator (how many room templates exist for this biome per room type)
- Preview: sample shard summary (biome name, example room names, hazard list, loot table probability breakdown)
- Version History
- Referenced By (which shard modifiers affect this biome, which creatures have this biome affinity)

### 4.8 Shard Modifiers — List View

**Columns:**
- **Name** — display name
- **ID** — slug
- **Effects** — summarized (e.g., "+30% rooms, +20% loot")
- **Tier Availability** — badges (T1/T2/T3)
- **Weight** — roll probability weight
- **Status**

### 4.9 Shard Modifiers — Detail / Edit View

**Layout:** Two-column, no tabs.

**Left column:**
- ID slug, display name, description
- Tier availability (multi-select checkboxes: T1, T2, T3)
- Roll weight (integer input with percentage indication based on total weights of all modifiers)
- Stackable toggle
- Exclusions (multi-select Reference Picker → other modifiers)
- **Effects editor:** A dynamic list of key-value pairs. Each row has a dropdown of available effect keys (see §2.4) and an appropriate input control for the value type (decimal, integer, boolean). "Add Effect" button.

**Right column:**
- Preview: textual summary of what this modifier does to a shard
- Conflict indicator: shows if any exclusion rules create impossible combinations
- Referenced By: which biomes or shard configurations use this modifier
- Version History

### 4.10 Loot Tables — List View

**Columns:**
- **Name** — display name
- **ID** — slug
- **Context** — creature / biome / container / event
- **Entry Count** — number of items in the table
- **Drop Count** — min–max drops per roll
- **Status**

### 4.11 Loot Tables — Detail / Edit View

**Layout:** Two-column.

**Left column:**
- ID slug, display name, context tag
- Tier restriction dropdown (limits max gear tier for entries)
- Drop count: min/max integer inputs
- **Entries table:** Sortable, editable rows. Each row: Item (Reference Picker with tier/type preview), Weight (integer), calculated probability (auto-computed, read-only). Drag-reorder. Add/Remove row.

**Right column:**
- **Drop Simulation panel:** Runs N simulated rolls (default 1,000). Shows bar chart of item drop frequencies. Configurable N.
- **Weight Distribution chart:** Pie chart showing relative probability of each item.
- Referenced By: which creatures and biomes use this loot table.
- Version History.

### 4.12 Skills — List View

**Columns:**
- **Display Name**
- **Slug**
- **Category** — colour-coded badge (combat=red, defence=blue, survival=green, subterfuge=purple, awareness=amber, social=pink)
- **Max Level**
- **Soft Cap**
- **Status**

**Filters:** Category (multi-select), Status.

### 4.13 Skills — Detail / Edit View

**Left column:**
- Slug, display name, description
- Category dropdown
- Max level (integer)
- XP curve: curve type dropdown (linear/exponential/logarithmic) + parameters (base XP per level, scaling factor). An interactive graph showing XP required per level updates live as parameters change.
- Soft cap level (integer) + soft cap multiplier (decimal)
- **Passive Effects editor:** Milestone-based. Add rows of "At level X, grant effect Y". Effects are typed key-value pairs (e.g., `dodgeChanceBonus: +5%`, `hearingRangeBonus: +1 room`).

**Right column:**
- XP curve visualization (line graph: level on X-axis, total XP on Y-axis)
- Effective stats table: at level 1, 10, 25, 50, max — shows cumulative passive effects
- Version History

### 4.14 Factions — List View

**Columns:**
- **Name**
- **Slug**
- **Philosophy** (truncated)
- **Specialty** (truncated)
- **Rank Count** — number of defined ranks
- **Status**

### 4.15 Factions — Detail / Edit View

**Left column:**
- Slug, display name, philosophy (text area), specialty (text area)
- **Ranks editor:** Ordered list of rank definitions. Each rank has:
  - Rank number (auto-incremented, read-only)
  - Name (text)
  - Reputation required (integer, must be > previous rank)
  - Unlocks (multi-select Reference Picker → Items, Recipes)

**Right column:**
- Rank progression visualization: vertical timeline showing ranks, reputation thresholds, and unlock icons
- Member count (read from live data if available — "Currently X players in this faction")
- Version History

### 4.16 Room Templates — List View

**Columns:**
- **Name**
- **Room Type** — badge (entry/extraction/boss/corridor/junction/dead_end)
- **Biome** — linked biome name
- **Features** — tag list (truncated)
- **Light Level** — numeric
- **Status**

**Filters:** Biome (multi-select), Room Type (multi-select), Status.

### 4.17 Room Templates — Detail / Edit View

**Left column:**
- ID slug, display name
- Room type dropdown
- Biome (Reference Picker → Biomes)
- Description template (Handlebars-style rich text editor with variable autocomplete)
- Features (tag list input — freeform slugs)
- Default light level (slider 0.0–1.0 with visual light/dark indicator)
- Sound propagation modifier (slider 0.5–2.0)
- Hazard slots (integer 0–5)

**Right column:**
- Preview: Rendered room description using mock player context. Shows how the LLM would present this room.
- Related rooms: other templates in the same biome
- Version History

### 4.18 Narrative Templates — List View

**Columns:**
- **ID**
- **Narration Type** — room_description / combat_action / combat_round / movement / event
- **Biome Scope** — biome name or "All"
- **Tone**
- **Verbosity**
- **Status**

**Filters:** Narration Type, Biome Scope, Tone, Verbosity.

### 4.19 Narrative Templates — Detail / Edit View

**Left column:**
- ID slug
- Narration type scope (dropdown)
- Biome scope (Reference Picker or "All Biomes")
- Tone (dropdown: dread / wonder / tension / calm)
- Verbosity (dropdown: terse / standard / verbose)
- Max tokens (integer, 20–500)
- **Template editor:** Full-width code/text editor with:
  - Handlebars syntax highlighting
  - Variable autocomplete (`{{room.biome}}`, `{{creature.name}}`, `{{player.hp_pct}}`, etc.)
  - Character/token counter
  - Line numbers

**Right column:**
- **Live Preview:** Renders the template with mock data, updating as the user types. Mock data is configurable (select biome, set creature count, set light level, etc.).
- **Variable Reference:** Collapsible panel listing all available template variables with descriptions
- Version History

### 4.20 Balance Constants — Editor

**Purpose:** Single page for all game-wide numeric constants. Uses Pattern B (grouped editor).

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  Balance Constants                                    [Save Changes] │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ▼ Combat                                                            │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Default Player HP:     [100]    Default Attack:  [10]         │  │
│  │ Default Defence:       [5  ]    Default Armour:  [2 ]         │  │
│  │ Combat Timeout (ticks):[10 ]                                  │  │
│  │                                                               │  │
│  │ Stance Multiplier Matrix:                                     │  │
│  │ ┌───────────┬────────┬────────┬────────┐                     │  │
│  │ │ Attacker  │ Strike │ Dodge  │ Flee   │                     │  │
│  │ ├───────────┼────────┼────────┼────────┤                     │  │
│  │ │ Strike    │ [1.0]  │ [0.5]  │ [1.0]  │                     │  │
│  │ └───────────┴────────┴────────┴────────┘                     │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ▼ Shard Generation                                                  │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Tier 1 Rooms:  min [15]  max [25]   Entries: [2]  Extr: [2]  │  │
│  │ Tier 2 Rooms:  min [25]  max [40]   Entries: [3]  Extr: [3]  │  │
│  │ Tier 3 Rooms:  min [40]  max [60]   Entries: [4]  Extr: [3]  │  │
│  │ Min Entry→Extraction Hops: [5]                                │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ▶ Loot Economy                                                      │
│  ▶ Inventory                                                         │
│  ▶ Extraction                                                        │
│  ▶ Sound                                                             │
│  ▶ Narration                                                         │
│                                                                      │
│  ── Version History ──                                               │
│  v12 (current) — Jane, 30 min ago — "Buffed T3 room counts"        │
│  v11 — Bob, 2d ago — "Reduced extraction noise"                     │
│  [View Full History]                                                 │
└──────────────────────────────────────────────────────────────────────┘
```

**Each group** is a collapsible section. All fields are inline-editable. Changes are saved as a single atomic unit (all balance constants are one versioned document).

**Validation:** Range constraints per field (e.g., HP > 0, multipliers > 0, room count min ≤ max). Warnings for extreme values (e.g., "Player HP below 50 may make combat too punishing").

### 4.21 Deploy Screen

**Purpose:** Content deployment pipeline — publish authored content from the admin tool to the game server.

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  Deploy Content                                                      │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Current Published Snapshot: v47 (deployed 2h ago by Jane)          │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │  Pending Changes (since v47):                                 │  │
│  │                                                               │  │
│  │  ✅ Creatures: Cinder Wraith (new), Drowned Revenant (edited)│  │
│  │  ✅ Items: Ember Shard (new)                                  │  │
│  │  ⚠  Biomes: Ember Rift (incomplete — missing 2 room types)  │  │
│  │  ✅ Balance: Combat timeout changed 10 → 12                  │  │
│  │                                                               │  │
│  │  3 publishable / 1 with warnings                             │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  [Preview Deployment Diff]                                           │
│  [Deploy to Staging]  [Deploy to Production]                         │
│                                                                      │
│  ── Deployment History ──                                            │
│  v47 — Jane — 2h ago — 5 changes — Production ✅                    │
│  v46 — Bob — 1d ago — 2 changes — Production ✅                     │
│  v45 — Jane — 2d ago — 8 changes — Production ✅ (rolled back →v44)│
│  [View Full History]                                                 │
└──────────────────────────────────────────────────────────────────────┘
```

**Elements:**
- **Current snapshot version** and deployment timestamp
- **Pending changes summary:** Lists all content that has been published (approved through review) since the last deployment. Shows per-domain breakdown with validation status.
- **Preview Deployment Diff:** Opens a full diff view showing exactly what content will change in the game server's data.
- **Deploy to Staging / Production buttons:** Staging deploys to a preview environment; Production deploys to live. Both require Admin role. Production requires confirmation modal ("This will affect live players. Are you sure?").
- **Deployment History:** List of past deployments with version, author, change count, target environment, and status. Rolled-back deploys are marked.

### 4.22 Audit Log

**Purpose:** Searchable, filterable history of all content changes across all domains.

**Layout:**

```
┌──────────────────────────────────────────────────────────────────────┐
│  Audit Log                                                           │
├──────────────────────────────────────────────────────────────────────┤
│  Filters: [Domain ▾] [Author ▾] [Action ▾] [Date range]            │
├──────────────────────────────────────────────────────────────────────┤
│  Timestamp          │ Author │ Domain    │ Action    │ Entity        │
│  ────────────────── ┼ ────── ┼ ───────── ┼ ───────── ┼ ──────────── │
│  2025-07-25 14:30   │ Jane   │ Creatures │ Published │ Cinder Wraith │
│  2025-07-25 14:28   │ Bob    │ Balance   │ Edited    │ Combat group  │
│  2025-07-25 13:00   │ Jane   │ Items     │ Created   │ Ember Shard   │
│  2025-07-25 12:45   │ Admin  │ Deploy    │ Deployed  │ v47 → Prod    │
│  ...                │        │           │           │               │
├──────────────────────────────────────────────────────────────────────┤
│  Showing 1–50 of 312  │ ◀ 1 2 3 4 5 ... ▶                          │
└──────────────────────────────────────────────────────────────────────┘
```

**Columns:** Timestamp, Author, Domain, Action (Created/Edited/Published/Deprecated/Deployed/Rolled Back/Deleted), Entity name (clickable to open detail).

**Filters:** Domain (multi-select), Author (multi-select), Action (multi-select), Date range picker.

**Export:** CSV export button for compliance/reporting.

### 4.23 User Management (Admin Only)

**Purpose:** Manage tool users and their roles.

**Layout:** Standard CRUD list + detail.

**List columns:** Username, Email, Role (Designer/Lead Designer/Admin), Last Active, Status (Active/Disabled).

**Detail fields:** Username, Email, Role dropdown, Status toggle. Change history per user.

**Actions:** Invite User (sends email invite), Edit Role, Disable/Enable Account.

---

## 5. Data Flow

### 5.1 Content Authoring → Game Server Pipeline

```
┌─────────────────┐    ┌──────────────────┐    ┌──────────────────────┐
│ Content Admin    │    │ PostgreSQL       │    │ Game Server          │
│ Tool (browser)   │    │ (content tables)  │    │ (Colyseus)           │
│                  │    │                  │    │                      │
│ 1. Designer      │    │                  │    │                      │
│    creates/edits │    │                  │    │                      │
│    content       │    │                  │    │                      │
│                  │    │                  │    │                      │
│ 2. Saves draft   │───►│ content_versions │    │                      │
│    (API call)    │    │ (status: draft)  │    │                      │
│                  │    │                  │    │                      │
│ 3. Review cycle  │───►│ content_versions │    │                      │
│    (approve)     │    │ (status: pub.)   │    │                      │
│                  │    │                  │    │                      │
│ 4. Deploy        │───►│ content_snapshots│───►│ 5. Server reads      │
│    (Admin action)│    │ (atomic version) │    │    content on:       │
│                  │    │                  │    │    - startup          │
│                  │    │                  │    │    - hot reload signal│
│                  │    │                  │    │    - shard seeding    │
│                  │    │                  │    │                      │
│                  │    │                  │    │ 6. Shard uses content │
│                  │    │                  │    │    for generation,    │
│                  │    │                  │    │    creatures, loot,   │
│                  │    │                  │    │    narration          │
└─────────────────┘    └──────────────────┘    └──────────────────────┘
```

### 5.2 Database Schema (Content Tables)

The content admin tool introduces new PostgreSQL tables alongside the existing game tables:

| Table | Purpose |
|-------|---------|
| `content_entries` | Primary content records (one row per content entity across all domains) |
| `content_versions` | Version history — every save creates a new version row |
| `content_snapshots` | Atomic deployment snapshots — maps a snapshot version to a set of content versions |
| `content_reviews` | Review records — who reviewed, when, approve/reject, comments |
| `content_audit_log` | Append-only audit trail of all actions |
| `content_users` | Tool user accounts and roles |

**Key relationships:**
- `content_entries` has a `domain` column (creature/item/biome/modifier/loot_table/skill/faction/room_template/narrative/balance/contract/recipe)
- `content_versions` has `entry_id` → `content_entries`, `data` (JSONB), `status` (draft/in_review/published/deprecated), `author_id`, `created_at`
- `content_snapshots` has `version` (integer), `deployed_at`, `deployed_by`, `environment` (staging/production), `entry_versions` (JSONB array mapping entry IDs to version IDs)

### 5.3 Content Loading at Runtime

The game server loads content from PostgreSQL at three points:

1. **Server startup:** Reads the latest deployed content snapshot. Builds in-memory registries (creature templates, item definitions, biome data, loot tables, balance constants). Replaces the current hardcoded TypeScript constants.

2. **Hot reload signal:** An API endpoint (`POST /admin/api/content/reload`) triggers the server to re-read content from the DB without restarting. Active shards continue with their existing content; only newly seeded shards use the updated content.

3. **Shard seeding:** When a new shard is created, the generator reads creature templates, biome data, loot tables, room templates, and modifiers from the in-memory content registry (populated at startup or hot reload).

### 5.4 Backward Compatibility

During the migration period, the game server supports both modes:
- **Legacy mode** (no DATABASE_URL or no content tables): Falls back to hardcoded TypeScript content (current behaviour)
- **Content DB mode** (content tables populated): Reads from DB, ignoring hardcoded constants

This ensures the content admin tool can be developed and deployed incrementally.

---

## 6. Content Lifecycle

### 6.1 State Machine

```
                 ┌──────────┐
                 │          │
      ┌─────────►  DRAFT   ◄───────────────────┐
      │          │          │                    │
      │          └─────┬────┘                    │
      │                │                         │
      │          Submit for Review          Reject (with comments)
      │                │                         │
      │                ▼                         │
      │          ┌──────────┐                    │
      │          │          │                    │
      │          │IN REVIEW │────────────────────┘
      │          │          │
      │          └─────┬────┘
      │                │
      │             Approve
      │                │
      │                ▼
      │          ┌──────────┐         ┌──────────────┐
      │          │          │         │              │
      │          │PUBLISHED │────────►│ DEPRECATED   │
      │          │          │         │              │
      │          └─────┬────┘         └──────┬───────┘
      │                │                     │
      │           Edit (creates              │
      │           new draft version)    Un-deprecate
      │                │                     │
      └────────────────┘                     │
                                             │
                       ┌─────────────────────┘
                       │
                       ▼
                 ┌──────────┐
                 │PUBLISHED │ (restored)
                 └──────────┘
```

### 6.2 State Definitions

| State | Description | Visible to Game Server | Editable |
|-------|-------------|----------------------|----------|
| **Draft** | Work in progress. Not visible to the game. Can be freely edited. | No | Yes |
| **In Review** | Submitted for Lead Designer approval. Read-only until reviewed. | No | No (reviewer can add comments) |
| **Published** | Approved and included in the next content deployment. | Yes (after deploy) | Creates new draft version |
| **Deprecated** | Retired from active use. Excluded from new shard generation. Still present in running shards. | Excluded from new generation | Can be un-deprecated |

### 6.3 Transition Rules

| From | To | Who Can | Conditions |
|------|----|---------|------------|
| Draft | In Review | Designer, Lead Designer | All required fields valid, no broken references |
| In Review | Published | Lead Designer, Admin | Reviewer approves |
| In Review | Draft | Lead Designer, Admin | Reviewer rejects (must add comment) |
| Published | Draft (new version) | Designer, Lead Designer | Automatic — editing published content creates draft |
| Published | Deprecated | Lead Designer, Admin | Confirmation required |
| Deprecated | Published | Lead Designer, Admin | Confirmation required |

### 6.4 Version Numbering

- Each content entry has an auto-incrementing version number (v1, v2, v3...)
- Version is incremented on every save (including draft saves)
- Published versions are tagged with the deployment snapshot version
- Version history is immutable — no version can be deleted or modified

---

## 7. Access Control

### 7.1 Roles

| Role | Permissions |
|------|------------|
| **Designer** | Create and edit content (own drafts). Submit for review. View all published content. Use preview features. View audit log (own actions only). |
| **Lead Designer** | All Designer permissions + Review and approve/reject content. Publish content. Deprecate and un-deprecate content. View full audit log. Set balance constants. |
| **Admin** | All Lead Designer permissions + Manage users (invite, edit roles, disable). Deploy content to staging/production. Trigger hot-reload on game server. View system configuration. Roll back deployments. |

### 7.2 Authentication

The content admin tool uses its own authentication system, separate from player authentication:
- **Phase 1:** Email + password with bcrypt hashing (consistent with game server auth pattern)
- **Future:** SSO via Azure Entra ID (aligns with Azure hosting directive)

### 7.3 Authorization Model

Every API endpoint checks:
1. **Authentication:** Valid session token
2. **Role check:** User's role has permission for the requested action
3. **Ownership check (for Designers):** Can only edit own draft content; cannot edit others' drafts

### 7.4 Session Management

- JWT tokens with 8-hour expiry (matches a working day)
- Refresh tokens with 30-day expiry
- "Remember me" option extends session to 30 days
- Concurrent sessions allowed (designer may have multiple tabs/devices)

---

## 8. Technical Integration Points

### 8.1 Architecture Placement

```
┌─────────────────────────────────────────────────────────────────────┐
│                       Azure Container Apps Environment               │
│                                                                     │
│  ┌─────────────────────┐    ┌────────────────────────────────────┐  │
│  │ Content Admin Tool   │    │ Game Server (Colyseus)             │  │
│  │ (Separate container) │    │                                    │  │
│  │                      │    │  ┌──────────┐  ┌───────────────┐  │  │
│  │  React SPA +         │    │  │ShardRoom │  │ Content       │  │  │
│  │  Express API         │    │  │          │  │ Registry      │  │  │
│  │                      │    │  └──────────┘  │ (in-memory)   │  │  │
│  │  /api/content/*      │    │                │ Loaded from DB│  │  │
│  │  /api/auth/*         │    │  ┌──────────┐  └───────────────┘  │  │
│  │  /api/deploy/*       │    │  │RefugeRoom│                     │  │
│  │  /api/audit/*        │    │  └──────────┘                     │  │
│  └──────────┬───────────┘    └────────────┬──────────────────────┘  │
│             │                             │                         │
│             │  Reads/writes content       │  Reads published        │
│             │  tables                     │  content snapshots      │
│             ▼                             ▼                         │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │  PostgreSQL (Azure DB for PostgreSQL Flexible Server)         │   │
│  │                                                              │   │
│  │  Existing tables:        Content tables (new):               │   │
│  │  • player_identities     • content_entries                   │   │
│  │  • players               • content_versions                  │   │
│  │  • item_definitions      • content_snapshots                 │   │
│  │  • player_stash          • content_reviews                   │   │
│  │  • player_skills         • content_audit_log                 │   │
│  │  • factions              • content_users                     │   │
│  │  • faction_membership                                        │   │
│  │  • run_history                                               │   │
│  └──────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  ┌──────────────┐                                                   │
│  │ Redis         │  Content admin does NOT use Redis.               │
│  │ (LLM cache +  │  Redis remains game-server-only for LLM cache   │
│  │  presence)    │  and Colyseus presence.                          │
│  └──────────────┘                                                   │
└─────────────────────────────────────────────────────────────────────┘
```

### 8.2 Key Integration Points

| Integration | Description | Direction |
|------------|-------------|-----------|
| **PostgreSQL (content tables)** | Content admin reads/writes content data via its own API. Game server reads published content snapshots. | Admin → DB ← Game Server |
| **Game Server hot-reload** | Admin tool calls `POST /admin/api/content/reload` on the game server (authenticated with `ADMIN_TOKEN`) to trigger in-memory content refresh. | Admin → Game Server |
| **LLM Pipeline** | Narrative templates authored in the admin tool feed into the LLM fallback template system. The game server's narration pipeline reads templates from the content registry. | Admin → DB → Game Server → LLM Pipeline |
| **Existing `item_definitions` table** | Migration path: the existing `item_definitions` table (migration 002) is replaced by content-admin-managed items. A data migration moves existing rows into the content system. | One-time migration |
| **Existing `factions` table** | Same migration pattern: existing seeded factions move into content-admin-managed entities. | One-time migration |

### 8.3 API Design

The content admin tool exposes a RESTful API:

```
POST   /api/auth/login
POST   /api/auth/logout
GET    /api/auth/me

GET    /api/content/:domain                    # List entries
POST   /api/content/:domain                    # Create entry
GET    /api/content/:domain/:id                # Get entry (latest version)
PUT    /api/content/:domain/:id                # Update entry (creates new version)
DELETE /api/content/:domain/:id                # Delete draft entry
GET    /api/content/:domain/:id/versions       # List versions
GET    /api/content/:domain/:id/versions/:v    # Get specific version
POST   /api/content/:domain/:id/submit-review  # Submit for review
POST   /api/content/:domain/:id/approve        # Approve (Lead Designer+)
POST   /api/content/:domain/:id/reject         # Reject (Lead Designer+)
POST   /api/content/:domain/:id/publish        # Direct publish (Lead Designer+)
POST   /api/content/:domain/:id/deprecate      # Deprecate (Lead Designer+)
POST   /api/content/:domain/:id/undeprecate    # Un-deprecate

GET    /api/content/:domain/:id/references     # Cross-reference lookup
POST   /api/content/:domain/:id/preview        # Generate preview

GET    /api/deploy/pending                     # Pending changes since last deploy
POST   /api/deploy/staging                     # Deploy to staging
POST   /api/deploy/production                  # Deploy to production
GET    /api/deploy/history                     # Deployment history
POST   /api/deploy/rollback/:version           # Roll back to specific version

GET    /api/audit                              # Audit log (filtered)
GET    /api/users                              # List users (Admin only)
POST   /api/users                              # Create user (Admin only)
PUT    /api/users/:id                          # Edit user (Admin only)
```

### 8.4 Technology Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| **Frontend** | React + TypeScript + Tailwind CSS | Consistent with game client stack |
| **Backend** | Express.js + TypeScript | Consistent with game server stack |
| **Database** | PostgreSQL (shared instance) | Reuse existing Azure DB for PostgreSQL |
| **Auth** | JWT (bcrypt passwords) | Matches game server auth pattern |
| **Hosting** | Azure Container Apps (separate container) | Same environment as game server |

---

## 9. Content Preview

### 9.1 Preview Types

| Preview Type | Domain(s) | What It Shows |
|-------------|-----------|---------------|
| **Stat Block** | Creatures, Items | Formatted display of all combat-relevant stats, with tier colour coding |
| **Loot Simulation** | Creatures, Loot Tables, Biomes | Monte Carlo simulation of N rolls, showing drop frequency distribution |
| **Room Description** | Room Templates, Biomes, Narrative | Rendered LLM-style prose using the template + mock game state |
| **Shard Preview** | Biomes, Modifiers, Balance | Summary of what a shard would look like: room count, creature spawns, loot quality, modifier effects |
| **XP Curve Graph** | Skills | Interactive line chart showing XP required per level, with soft cap marked |
| **Rank Timeline** | Factions | Visual progression of ranks with reputation thresholds and unlock icons |
| **Effective Stats** | Items | Item stats after applying rarity tier multipliers |
| **Drop Probability** | Loot Tables | Calculated probability per item based on weights |

### 9.2 Preview Architecture

Previews are generated **client-side** using the same calculation logic as the game server (shared via `packages/shared/`). This means:
- No server round-trip for stat calculations
- Instant feedback as designers edit values
- The shared package's `RARITY_TIERS`, damage formulas, and loot roll algorithms are the source of truth

For narrative template previews, the admin tool backend renders Handlebars templates against mock NarrationContext objects. The mock data is configurable by the designer (select biome, adjust light level, set creature count, etc.).

### 9.3 Preview vs. Live Test

Preview shows **calculated approximations**. For full validation, the Deploy screen supports **staging deployment** — content is deployed to a staging environment where designers can enter actual shards and see their content in a live game loop. This is the definitive test.

---

## 10. Versioning & Rollback

### 10.1 Version Granularity

- **Entry-level versioning:** Every content entry (creature, item, biome, etc.) has its own independent version history. Saving any change increments the version.
- **Snapshot-level versioning:** Deployments create atomic snapshots that map each entry to a specific version. This is the unit of deployment and rollback.

### 10.2 Version Storage

```
content_versions
├── id (UUID)
├── entry_id → content_entries.id
├── version_number (integer, auto-increment per entry)
├── data (JSONB — full content payload)
├── status (draft / in_review / published / deprecated)
├── author_id → content_users.id
├── reviewer_id → content_users.id (nullable)
├── review_comment (text, nullable)
├── created_at (timestamp)
└── published_at (timestamp, nullable)

content_snapshots
├── id (UUID)
├── version (integer, auto-increment global)
├── entry_versions (JSONB — { entry_id: version_id } mapping)
├── deployed_by → content_users.id
├── deployed_at (timestamp)
├── environment (staging / production)
├── status (active / rolled_back)
└── rollback_target (nullable → content_snapshots.id)
```

### 10.3 Rollback Procedure

1. **Admin** navigates to Deploy → Deployment History
2. Selects a previous snapshot version (e.g., v45)
3. Clicks "Roll Back to v45" — confirmation modal shows the diff between current and target
4. On confirmation:
   - A new snapshot is created (v48) that points to the same entry versions as v45
   - The current snapshot (v47) is marked `status: rolled_back`
   - Game server receives hot-reload signal
   - Newly seeded shards use the rolled-back content; active shards are unaffected
5. The rollback is recorded in the audit log

### 10.4 Diff Viewer

The diff viewer shows:
- **Field-level diffs** for simple values (old value → new value, highlighted in red/green)
- **Structural diffs** for arrays (added/removed/reordered entries in loot tables, room name lists, etc.)
- **JSONB deep diff** for complex nested objects

### 10.5 Retention Policy

- All versions are retained indefinitely (storage is cheap; content volume is low)
- Deleted drafts are soft-deleted (marked deleted, excluded from queries, but retained for audit)
- Deployment snapshots are never deleted

---

## Appendix A: Content Domain → GDD Section Mapping

| Content Domain | GDD Sections | Current Codebase Location |
|---------------|-------------|--------------------------|
| Creatures | §6.6, §10.2, §10.4 | `packages/server/src/creatures/` |
| Items | §7.2, §9.1 | `packages/server/src/items/registry.ts`, `packages/shared/src/items.ts` |
| Biomes | §10.2 | `packages/server/src/shard/biomes/` |
| Shard Modifiers | §10.3 | `packages/shared/src/index.ts` (ShardModifier type) |
| Loot Tables | §10.4 | `packages/server/src/items/loot-drops.ts` |
| Skills | §7.1 | `packages/server/src/db/types.ts` (SkillCategory, PlayerSkill) |
| Factions | §9.4 | `packages/server/src/db/types.ts` (Faction types), migration 004 |
| Room Templates | §10.1, §10.2 | `packages/shared/src/room-graph.ts`, `packages/server/src/shard/biomes/` |
| Narrative Templates | §4.2–§4.5 | `packages/shared/src/narrative-types.ts` |
| Balance Constants | §5.2, §6.4, §7.1, §10, §12 | Scattered across combat, shard, extraction, items modules |
| Contracts | §2.1, §9.4 | Not yet implemented (Phase 4) |
| Crafting Recipes | §9.2 | Not yet implemented (Phase 3) |

## Appendix B: Validation Rules Summary

### Cross-Reference Integrity

| Source | References | Validation |
|--------|-----------|------------|
| Creature loot table entry | Item | Item must exist (Published or Draft in same snapshot) |
| Biome loot table entry | Item | Item must exist |
| Biome signature creature | Creature | Creature must exist |
| Blueprint `unlocksRecipeId` | Recipe | Recipe must exist |
| Recipe output item | Item | Item must exist |
| Recipe materials | Items | All items must exist |
| Recipe required faction | Faction | Faction must exist |
| Contract objectives | Creatures, Items | Referenced entities must exist |
| Contract rewards | Items | Items must exist |
| Modifier exclusions | Other Modifiers | Referenced modifiers must exist |
| Faction rank unlocks | Items, Recipes | Referenced entities must exist |

### Deletion Protection

Published content that is referenced by other published content **cannot be deprecated** until references are removed. The tool shows a "Referenced By" warning listing all dependent entities.

Draft content can always be deleted (soft-delete). If a draft references another draft that gets deleted, a broken reference warning appears on the next validation pass.

## Appendix C: Glossary

| Term | Definition |
|------|-----------|
| **Content Entry** | A single authored entity (one creature, one item, one biome, etc.) |
| **Content Version** | A specific revision of a content entry, identified by version number |
| **Content Snapshot** | An atomic collection of content versions, representing the full game content state at a point in time |
| **Deployment** | The act of making a content snapshot available to the game server |
| **Hot Reload** | Instructing the game server to re-read content from the database without restarting |
| **Reference Picker** | UI component for selecting and linking to another content entry |
| **Draft** | Unpublished, in-progress content not visible to the game server |
| **Published** | Approved content included in the next deployment snapshot |
